---
name: html-artifact
description: Create polished single-file HTML artifacts as an alternative to markdown for documents meant to be read by humans. Use whenever the user asks for an implementation plan, status report, post-mortem, architecture doc, scaling analysis, capacity dashboard, research explainer, concept walkthrough, PR writeup, or other long-form documents that benefit from richer structure than markdown — KPI tiles, charts, tables, mockups, code blocks with copy buttons, collapsibles, SVG diagrams, or small interactive controls. Also use when the user asks for "an HTML file", "HTML artifact", "HTML doc", "HTML version of this", or "a one-pager". Do NOT use for React components, web apps, marketing pages, or visually expressive design (use frontend-design); for READMEs, docstrings, agent prompts, CLAUDE.md, or anything destined for git/CLI/another agent (use markdown); or for content under ~50 lines where visual structure doesn't earn its weight.
---

# html-artifact

Standalone single-file HTML documents that replace what would otherwise be a long markdown file. Goal: readability and credibility — Stripe docs, not portfolio site.

## When to use

Run this check first. If markdown is the right answer, write markdown.

**HTML when all hold:**
- Output is for humans, not for another agent or pipeline to ingest
- Visual structure adds information: tables, diagrams, mockups, side-by-sides, charts, severity colors, interactive controls
- ~50+ lines — scaffolding has to earn its weight
- User wants to share or reference, not hand-edit

**Markdown when any hold:**
- README, CLAUDE.md, agent prompt, docstring, or other source-of-truth file
- Lives in git, reviewed in PR diffs
- Ingested by another LLM, RAG, or eval system
- Destined for a markdown-native surface (GitHub, Linear, Slack)
- Short enough that scaffolding doesn't pay for itself

**frontend-design instead when:** user wants a React/Vue component, landing page, or expressive design where the aesthetic goal is "memorable" rather than "credible".

If unsure, ask before producing.

## Standalone-file invariants

Single self-contained `.html` that works double-clicked. Non-negotiable:

- `<meta name="viewport" content="width=device-width, initial-scale=1">`
- Inline CSS in one `<style>` block. CDN externals only when justified.
- Inline JS. Vanilla by default. No build step.
- Dark mode via `prefers-color-scheme: dark`
- No external trackers or analytics
- Works on `file://` — no same-origin fetches, no service workers
- System fonts only (`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Inter, sans-serif`). No Google Fonts.
- Collapses to single column under 720px
- Readable with JS disabled — interactivity is progressive

`assets/starter-template.html` embodies all of these plus the design tokens. Branch from it.

## Design tokens

CSS custom properties for color, space, type — full definitions in `starter-template.html`. Keep them unless the user requests specific values.

Color discipline: neutral page; `--accent` for one or two anchor elements only (primary KPI, copy button, active tab); severity colors only for status/risk.

## Shared component vocabulary

Markup and CSS live in `starter-template.html`. Available in every preset:

- **KPI tile row** — 3-5 cards: big number, label, optional delta
- **Numbered section header** — large grey "01", "02" before the title
- **Code block with copy button** — `<pre><code>` plus a clipboard button
- **Severity tag** — small rounded pill in high/med/low colors
- **Collapsible** — native `<details><summary>`, works without JS
- **Inline SVG diagram** — real SVG, not unicode or ASCII

## Presets

Pick exactly one. Read the matching reference before writing.

- **report** — plans, status updates, post-mortems, architecture docs, design specs → `references/preset-report.md`
- **dashboard** — chart-first analyses, capacity, scaling studies, comparisons → `references/preset-dashboard.md`
- **explainer** — "how X works", concept teaching, research summaries → `references/preset-explainer.md`
- **editor** — tuners, config editors, triage boards, anything with "copy back to prompt" → `references/preset-editor.md`

If a request doesn't cleanly fit one, default to `report`. If it spans two, use the dominant as the spine and embed the secondary as a section.

## Anti-patterns

- Gradient hero with centered headline and CTA — the universal "AI website" tell
- Glassmorphism, neon, "shadcn card everywhere" — reports aren't landing pages
- Google Fonts — system fonts are faster and more credible
- Walls of `<p>` with no scaffolding — that's why we picked HTML
- 5MB artifacts for 500 words — don't import Chart.js for three bars
- Animations on initial render — doc must be readable instantly
- Buttons that look tappable but do nothing — render as text if non-interactive
- Lorem ipsum, invented metrics, fake names or timestamps

## Output protocol

Save to `/mnt/user-data/outputs/` with a descriptive filename. Call `present_files`. Don't paste HTML source into chat — one or two sentences of context is enough.
