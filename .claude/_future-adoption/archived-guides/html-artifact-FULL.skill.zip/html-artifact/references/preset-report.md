# Preset: report

For plans, status updates, post-mortems, architecture docs, design specs, retrospectives — anywhere a reader expects to skim by section.

## Skeleton

```
<header>      title + 1-line subtitle
<div kpi-row> 3-5 KPI tiles
<section data-num="01"> ... </section>
<section data-num="02"> ... </section>
... 4-7 sections total
<footer>      sources, generated stamp
```

Reader's path: KPIs orient, numbered sections enable jumping, footer establishes currency. They should answer "what is this and is it current?" in five seconds.

## Section order by report type

- **Implementation plan**: Milestones · Data flow · Mockups · Key code · Risks · Open questions
- **Status report**: KPIs · Highlights · Shipped · In flight · Blocked/slipped · Sources
- **Post-mortem**: Summary · Timeline · Root cause · Customer impact · Follow-ups · Sources
- **Architecture doc**: Context · System diagram · Components · Data flow · Failure modes · Capacity
- **Design spec**: Problem · Constraints · Proposal · Alternatives · Open questions

## Patterns

Base styles (KPI tile, numbered section, severity tag, code block, table, footer) live in `starter-template.html`. The patterns below are specific to `report`.

### Risk / open-question table

```html
<table>
  <thead><tr><th>Risk</th><th>Sev</th><th>Mitigation</th></tr></thead>
  <tbody>
    <tr>
      <td>Realtime duplicate from socket racing the HTTP response.</td>
      <td><span class="sev sev-high">HIGH</span></td>
      <td>Dedupe on server-assigned id in the cache updater.</td>
    </tr>
  </tbody>
</table>
```

### Code block with caption

```html
<figure class="codefig">
  <figcaption>packages/db/migrations/0042_comments.sql</figcaption>
  <button class="copy-btn" data-copy>Copy</button>
  <pre><code>create table comments (
  id uuid primary key default gen_random_uuid(),
  ...
);</code></pre>
</figure>
```

Copy-button JS is wired in `starter-template.html`.

### Inline mockup

Sketch the UI using the page's tokens, not a screenshot. It should look like part of the doc.

```html
<div class="mockup">
  <div class="mockup-label">A · Thread inside an open task card</div>
  <div class="mockup-frame">
    <!-- mock HTML using --surface, --border, --text-muted -->
  </div>
</div>
```

```css
.mockup { margin: var(--sp-5) 0; padding: var(--sp-4); border: 1px solid var(--border); border-radius: var(--radius); background: var(--surface); }
.mockup-label { font-size: var(--fs-1); color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: var(--sp-3); }
.mockup-frame { border: 1px dashed var(--border); padding: var(--sp-4); border-radius: var(--radius); }
```

## Acceptable deviations

- Drop the KPI row if there are genuinely no numeric facts (rare — even "last updated" works).
- Sticky TOC sidebar on viewports >1080px when the doc has 8+ sections.
- Two-column layout for sections where a diagram pairs with its caption.
