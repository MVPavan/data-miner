# Preset: editor

Interactive throwaway editors: prompt tuners, config editors, triage boards, calibration tools, annotation interfaces. The reader's job is to do something and export the result.

## Hard rule

Every editor ends with at least one export button. Output is paste-ready: JSON, markdown, prompt, YAML — whatever the user feeds back to the agent or commits. Without export, the work disappears.

## When editor vs other presets

Signal phrases: "tune", "tweak", "reorder", "tag", "approve/reject", "calibrate", "drag", "pick a value for". If the user just wants to read, use `report` or `explainer`.

## Skeleton

```
<header>                title + 1-line "what this lets you do"
<aside instructions>    2-3 line how-to, optional
<main editor-shell>
  <section controls>    inputs, knobs, drag targets
  <section preview>     live result
</main>
<div export-bar>        Copy as X · Reset
```

Two columns above 720px, stacked below.

```css
.editor-shell { display: grid; grid-template-columns: 1fr 1fr; gap: var(--sp-5); align-items: start; }
@media (max-width: 720px) { .editor-shell { grid-template-columns: 1fr; } }
```

## State

Plain object in JS. Re-render on every change. No frameworks.

```js
const state = { template: '', samples: [...], selectedTab: 'curl' };

function render() { /* read state, write DOM */ }

function setState(patch) { Object.assign(state, patch); render(); }

document.querySelector('#template').addEventListener('input', e =>
  setState({ template: e.target.value }));
```

For ~200+ lines of editor logic, split into `renderControls`, `renderPreview`, `renderExport` so you only call what changed.

## Export button

```html
<div class="export-bar">
  <button class="btn btn-primary" id="export-json">Copy as JSON</button>
  <button class="btn" id="export-md">Copy as markdown</button>
  <button class="btn btn-ghost" id="reset">Reset</button>
  <span id="flash"></span>
</div>
```

```css
.export-bar { position: sticky; bottom: 0; background: var(--surface); border-top: 1px solid var(--border); padding: var(--sp-3) var(--sp-4); display: flex; gap: var(--sp-3); justify-content: flex-end; margin-top: var(--sp-6); }
.btn { padding: var(--sp-2) var(--sp-4); border: 1px solid var(--border); border-radius: var(--radius); background: var(--surface); font: inherit; cursor: pointer; color: var(--text); }
.btn-primary { background: var(--accent); color: var(--bg); border-color: var(--accent); }
.btn-ghost { border-color: transparent; color: var(--text-muted); }
```

```js
document.getElementById('export-json').addEventListener('click', async () => {
  await navigator.clipboard.writeText(JSON.stringify(buildExport(state), null, 2));
  flash('Copied as JSON');
});

function flash(msg) {
  const el = document.getElementById('flash');
  el.textContent = msg;
  setTimeout(() => el.textContent = '', 1500);
}
```

Sticky bottom positioning so the button never scrolls out of reach. Flash confirmation is essential — without it, the user doesn't know the click worked.

## Common patterns

**Live template preview** — editable textarea left, rendered output for several sample inputs right. Highlight variable slots. Pre-fill with a sensible default; never start empty.

**Drag-to-reorder buckets** — columns + draggable cards using HTML5 drag-and-drop. Export emits final ordering grouped by bucket.

**Config editor with validation** — fields grouped by area, inline warnings on broken constraints (e.g. flag with prerequisite off). Export a *diff* of changed keys, not full config.

**Calibration / picker** — for values painful to express in text (color, easing curve, cron schedule, threshold values). Sliders + numeric display + live preview. SigLIP2 threshold tuning and hard-negative margin conditions fit here: sliders left, live detection preview right, copy thresholds as YAML at bottom.

## Don'ts

- No "save" button — there's no backend; "save" with no destination is a lie. Use "copy" or "download".
- No localStorage — artifacts are throwaway, persistence confuses.
- No login screen, ever.
- No fetches to external APIs unless explicitly requested.
- No 200KB script for a 10-card triage board.

## Acceptable deviations

- Alpine.js or Vue via CDN for complex editors (mention the cost in the response).
- Keyboard shortcuts in addition to visible buttons. Never keyboard-only.
- "Last export" `<details>` block so the user can review what they copied without re-clicking.
