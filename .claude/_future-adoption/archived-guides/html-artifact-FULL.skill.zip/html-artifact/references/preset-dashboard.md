# Preset: dashboard

Chart-first documents: scaling analyses, capacity views, metric explorations, A/B comparisons. Prose is captions, not body.

## When dashboard vs report

More than a paragraph between charts → use `report` and embed charts as figures. Dashboard is for cases where charts are the argument and prose only labels them.

## Skeleton

```
<header>      title + 1-line context + last-updated
<div kpi-row> 4-6 tiles with deltas
<section> primary chart, full width
<div chart-grid> secondary charts in 2 columns
<details> drill-down data table, collapsed
<footer>  source, refresh cadence
```

## Charts: SVG inline first

For bars, lines, scatter, and most distributions, hand-rolled SVG is smaller, instant-loading, dependency-free, and styled by the page's tokens.

```html
<figure class="chart">
  <figcaption>PRs merged per day · Mon–Sun</figcaption>
  <svg viewBox="0 0 700 200" role="img" aria-label="PRs merged per day">
    <line x1="40" y1="20" x2="40" y2="170" stroke="var(--border)"/>
    <line x1="40" y1="170" x2="680" y2="170" stroke="var(--border)"/>
    <g fill="var(--accent)">
      <rect x="60"  y="140" width="60" height="30"/>
      <rect x="150" y="100" width="60" height="70"/>
    </g>
    <g font-size="12" fill="var(--text-muted)" text-anchor="middle">
      <text x="90"  y="135">2</text>
      <text x="180" y="95">7</text>
    </g>
  </svg>
</figure>
```

```css
.chart { margin: var(--sp-5) 0; }
.chart figcaption { font-size: var(--fs-2); color: var(--text-muted); margin-bottom: var(--sp-2); }
.chart svg { width: 100%; height: auto; max-height: 320px; }
.chart-grid { display: grid; grid-template-columns: 1fr 1fr; gap: var(--sp-5); }
.chart-wide { grid-column: 1 / -1; }
@media (max-width: 720px) { .chart-grid { grid-template-columns: 1fr; } }
```

## Use a library only when

- Hover tooltips with detail breakdowns are required
- Chart type is genuinely complex (heatmap, treemap, sankey, force graph)
- User already uses a specific library in their pipeline — match it

CDN imports:
- Chart.js: `https://cdn.jsdelivr.net/npm/chart.js@4`
- D3: `https://cdn.jsdelivr.net/npm/d3@7`
- Plotly: `https://cdn.plot.ly/plotly-2.35.0.min.js`

When using a library, inline a `<noscript>` paragraph stating the headline number so the doc isn't useless without JS.

## Drill-down table

Raw numbers behind every chart. Collapsed by default; readers who want to verify need it without hunting.

```html
<details>
  <summary>Show underlying data</summary>
  <table>...</table>
</details>
```

## Color discipline

- One accent (`--accent`) for the primary series
- Neutrals for secondary
- Severity colors only for true pass/fail metrics — don't use red/green as ordinary series colors
- No rainbow palettes; if you need 5+ series, split into multiple charts

## Captions, not bodies

1-2 sentences per chart: the trend, the outlier, the comparison. Don't restate axis labels.

> Bad: "This chart shows PRs merged each day from Monday to Sunday."
> Good: "Thursday spike is the bulk-edit feature train (4 PRs landed together)."

## Acceptable deviations

- Date-range selector or series toggle if the user asks for exploration. Pure JS state, no backend.
- "Last updated" stamp with a faint pulse for live-status dashboards. No auto-refresh.
- For A vs B comparisons, share y-axis ranges explicitly — auto-scaled axes mislead.
