# Preset: explainer

"How X works", concept walkthroughs, onboarding docs, research summaries. The reader is new and chooses whether to invest each successive screen.

## Skeleton

```
<header>             title + 1-line "what you'll know after reading"
<aside class="tldr"> always present
<section> narrative section 1 (heading is a question)
<section> narrative section 2
... 3-6 sections
<dl class="glossary"> always present, even if short
<footer>
```

## TL;DR box

What it is, why it matters, the one gotcha. A reader who only reads the TL;DR still walks away with the headline.

```html
<aside class="tldr">
  <h2>TL;DR</h2>
  <ul>
    <li><strong>What:</strong> Rate limiting uses a token bucket per (user, endpoint).</li>
    <li><strong>Why it matters:</strong> Hitting the limit returns 429; the client must back off.</li>
    <li><strong>Gotcha:</strong> Buckets are in Redis and not durable — a restart wipes them.</li>
  </ul>
</aside>
```

```css
.tldr { background: var(--accent-soft); border-left: 4px solid var(--accent); padding: var(--sp-4) var(--sp-5); border-radius: var(--radius); margin: var(--sp-5) 0; }
.tldr h2 { margin: 0 0 var(--sp-2) 0; font-size: var(--fs-2); text-transform: uppercase; letter-spacing: 0.05em; color: var(--accent); }
.tldr ul { margin: 0; padding-left: var(--sp-5); }
.tldr li + li { margin-top: var(--sp-2); }
```

## Questions as section headings

"How does the bucket refill?" beats "Bucket refill mechanics". Readers match their own question to the section.

## Collapsible deep-dives

Native `<details><summary>` for asides off the main path. Base styles in `starter-template.html`.

## Inline SVG diagrams

For any process, lifecycle, or relationship — draw it. Use the page's color tokens so it feels part of the doc, not pasted in.

## Tabbed code samples

Multiple representations of the same idea (curl / Python / TS; config / code).

```html
<div class="tabs" data-tabs>
  <div class="tab-buttons" role="tablist">
    <button role="tab" aria-selected="true"  data-tab="curl">curl</button>
    <button role="tab" aria-selected="false" data-tab="py">Python</button>
  </div>
  <pre data-panel="curl"><code>curl -X POST ...</code></pre>
  <pre data-panel="py" hidden><code>requests.post(...)</code></pre>
</div>
```

```css
.tab-buttons { display: flex; gap: var(--sp-2); border-bottom: 1px solid var(--border); }
.tab-buttons button { background: none; border: none; padding: var(--sp-2) var(--sp-3); font: inherit; cursor: pointer; color: var(--text-muted); border-bottom: 2px solid transparent; }
.tab-buttons button[aria-selected="true"] { color: var(--text); border-bottom-color: var(--accent); }
.tabs pre { margin: 0; border-top-left-radius: 0; }
```

```js
document.querySelectorAll('[data-tabs]').forEach(g => {
  const btns = g.querySelectorAll('[data-tab]');
  const pnls = g.querySelectorAll('[data-panel]');
  btns.forEach(b => b.addEventListener('click', () => {
    btns.forEach(x => x.setAttribute('aria-selected', x === b));
    pnls.forEach(p => p.hidden = p.dataset.panel !== b.dataset.tab);
  }));
});
```

## Glossary

4-6 terms minimum. Hover-link body terms to entries via `<a href="#g-bucket">`.

```html
<dl class="glossary">
  <dt id="g-bucket">Bucket</dt>
  <dd>The per-(user, endpoint) container that holds tokens.</dd>
  <dt id="g-token">Token</dt>
  <dd>One unit of permission. Consumed on each accepted call.</dd>
</dl>
```

```css
.glossary { display: grid; grid-template-columns: max-content 1fr; gap: var(--sp-2) var(--sp-5); margin: var(--sp-6) 0; }
.glossary dt { font-weight: 600; }
.glossary dd { margin: 0; color: var(--text-muted); }
```

## Comparison table

When teaching a choice ("X vs Y"), end with a "When to pick" row. That's the row readers actually came for.

## Acceptable deviations

- Small interactive diagram (animated token bucket) when the concept is dynamic and a frozen frame doesn't carry it. Under ~30 lines of JS — bigger is an `editor`.
- Drop the glossary for known-audience docs (ask first).
- Floating mini-TOC at wide viewports for explainers above ~5000 words.
