---
name: html-artifact
description: Create polished single-file HTML artifacts as an alternative to markdown for documents meant to be read by humans. Use whenever the user asks for an implementation plan, status report, post-mortem, architecture doc, scaling analysis, capacity dashboard, research explainer, concept walkthrough, PR writeup, or other long-form documents that benefit from richer structure than markdown — KPI tiles, charts, tables, mockups, code blocks with copy buttons, collapsibles, SVG diagrams, or small interactive controls. Also use when the user asks for "an HTML file", "HTML artifact", "HTML doc", "HTML version of this", or "a one-pager". Do NOT use for React components, web apps, marketing pages, or visually expressive design (use frontend-design); for READMEs, docstrings, agent prompts, CLAUDE.md, or anything destined for git/CLI/another agent (use markdown); or for content under ~50 lines where visual structure doesn't earn its weight.
---

# html-artifact

Standalone single-file HTML documents that replace what would otherwise be a long markdown file. Goal: readability and credibility — Stripe docs, not portfolio site.

## When to use

**HTML when all hold:** output is for humans (not another agent or pipeline); visual structure adds information (tables, diagrams, mockups, charts, severity colors, interactive controls); content is ~50+ lines; user wants to share or reference, not hand-edit.

**Markdown when any hold:** README, CLAUDE.md, agent prompt, docstring; lives in git and reviewed in PR diffs; ingested by another LLM, RAG, or eval system; destined for a markdown-native surface (GitHub, Linear, Slack); too short for scaffolding to pay off.

**frontend-design instead when:** the aesthetic goal is "memorable / bold" rather than "readable / credible" — React components, landing pages, expressive design.

If unsure, ask before producing.

## Standalone-file invariants

Single self-contained `.html` that works double-clicked. Non-negotiable:

- `<meta name="viewport" content="width=device-width, initial-scale=1">`
- Inline CSS, inline JS, no build step
- Dark mode via `prefers-color-scheme: dark`
- No external trackers, no analytics, no fetches to third-party APIs
- Works on `file://` — no same-origin fetches, no service workers
- System fonts only — no Google Fonts
- Collapses to single column under 720px
- Readable with JS disabled — interactivity is progressive

## Design tokens

The skill ships **only** the design tokens, not layout rules. Use the tokens from `assets/starter-template.html` (CSS variables for color, space, type) and derive the layout fresh for each artifact.

This is deliberate: tokens enforce house style (same colors, same spacing scale, same fonts across every artifact you generate) without locking the layout into one rigid template. A 3-section report doesn't need the same scaffolding as a 7-section one.

**Color discipline:**
- Neutral page (`--bg`, `--surface`); reserve `--accent` for one or two anchor elements (a primary KPI, the copy button, the active tab)
- Severity colors only for status/risk. For severity tags, use a tinted background like `color-mix(in srgb, var(--sev-high) 15%, transparent)` with the full color as foreground — never raw severity as a large background

**Spacing discipline:** use the `--sp-*` scale exclusively. Don't hard-code px values.

**Type discipline:** use the `--fs-*` scale. Reserve `--fs-6` for one or two hero numbers per artifact (e.g. a primary KPI). Body is `--fs-3`.

## Conceptual component vocabulary

Every artifact has these affordances. Implement them fresh each time using the tokens. The reference files show the HTML structure and any tricky JS, but layout CSS is yours to derive.

- **KPI tile row** — 3-5 cards at the top: big number, label, optional delta. The fastest way to orient a reader.
- **Numbered section header** — large grey "01", "02" before the title. Signals scannable structure.
- **Code block with copy button** — `<pre><code>` plus a clipboard button in the top-right. (Copy JS in `references/snippets.md`.)
- **Severity tag** — small rounded pill in high/med/low colors with tinted background.
- **Collapsible** — native `<details><summary>` so JS-disabled readers still get content.
- **Inline SVG diagram** — real SVG using the page's color tokens, not unicode or ASCII.

## Presets

Pick exactly one. Read the matching reference before writing.

- **report** — plans, status updates, post-mortems, architecture docs, design specs → `references/preset-report.md`
- **dashboard** — chart-first analyses, capacity, scaling studies, comparisons → `references/preset-dashboard.md`
- **explainer** — "how X works", concept teaching, research summaries → `references/preset-explainer.md`
- **editor** — tuners, config editors, triage boards, anything with "copy back to prompt" → `references/preset-editor.md`

Tricky JS snippets (clipboard, tab switching, drag-drop) live in `references/snippets.md`. Read it when you need them.

## Anti-patterns

- Gradient hero with centered headline and CTA — the universal "AI website" tell
- Glassmorphism, neon, "shadcn card everywhere" — reports aren't landing pages
- Google Fonts — system fonts are faster and more credible
- Walls of `<p>` with no scaffolding — that's why we picked HTML
- 5MB artifacts for 500 words — don't import Chart.js for three bars
- Animations on initial render — doc must be readable instantly
- Buttons that look tappable but do nothing — render as text if non-interactive
- Lorem ipsum, invented metrics, fake names or timestamps
- Hard-coded pixel values when a token exists for that purpose

## Output protocol

Save to `/mnt/user-data/outputs/` with a descriptive filename. Call `present_files`. Don't paste HTML source into chat — one or two sentences of context is enough.
