# Snippets

Tricky JS patterns that aren't worth re-deriving. Copy verbatim.

## Copy-to-clipboard with flash confirmation

```html
<button class="copy-btn" data-copy>Copy</button>
```

```js
document.querySelectorAll('[data-copy]').forEach(btn => {
  btn.addEventListener('click', () => {
    const code = btn.parentElement.querySelector('code').textContent;
    navigator.clipboard.writeText(code);
    const orig = btn.textContent;
    btn.textContent = 'Copied';
    setTimeout(() => btn.textContent = orig, 1500);
  });
});
```

## Tab switcher (no framework)

```html
<div data-tabs>
  <div class="tab-buttons" role="tablist">
    <button role="tab" aria-selected="true"  data-tab="a">Tab A</button>
    <button role="tab" aria-selected="false" data-tab="b">Tab B</button>
  </div>
  <pre data-panel="a"><code>...</code></pre>
  <pre data-panel="b" hidden><code>...</code></pre>
</div>
```

```js
document.querySelectorAll('[data-tabs]').forEach(g => {
  const btns = g.querySelectorAll('[data-tab]');
  const pnls = g.querySelectorAll('[data-panel]');
  btns.forEach(b => b.addEventListener('click', () => {
    btns.forEach(x => x.setAttribute('aria-selected', x === b));
    pnls.forEach(p => p.hidden = p.dataset.panel !== b.dataset.tab);
  }));
});
```

## Drag-to-reorder buckets (HTML5 DnD)

```js
let dragId = null;
document.querySelectorAll('.card').forEach(card => {
  card.addEventListener('dragstart', () => { dragId = card.dataset.id; });
});
document.querySelectorAll('.column').forEach(col => {
  col.addEventListener('dragover', e => e.preventDefault());
  col.addEventListener('drop', () => { moveCard(dragId, col.dataset.bucket); render(); });
});
```

## Editor state pattern

```js
const state = { /* fields */ };

function render() { /* read state, write DOM */ }

function setState(patch) { Object.assign(state, patch); render(); }

document.querySelector('#some-input').addEventListener('input', e =>
  setState({ field: e.target.value }));
```

## Copy-as-X export with flash

```js
document.getElementById('export-json').addEventListener('click', async () => {
  await navigator.clipboard.writeText(JSON.stringify(buildExport(state), null, 2));
  flash('Copied as JSON');
});

function flash(msg) {
  const el = document.getElementById('flash');
  el.textContent = msg;
  setTimeout(() => el.textContent = '', 1500);
}
```

## Severity tag styling technique

Tinted background using `color-mix`, full color as foreground:

```css
.sev-high { background: color-mix(in srgb, var(--sev-high) 15%, transparent); color: var(--sev-high); }
.sev-med  { background: color-mix(in srgb, var(--sev-med)  15%, transparent); color: var(--sev-med); }
.sev-low  { background: color-mix(in srgb, var(--sev-low)  15%, transparent); color: var(--sev-low); }
```
