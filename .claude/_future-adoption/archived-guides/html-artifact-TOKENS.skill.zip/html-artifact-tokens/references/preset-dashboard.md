# Preset: dashboard

Chart-first documents: scaling analyses, capacity views, metric explorations, A/B comparisons. Prose is captions, not body.

## When dashboard vs report

More than a paragraph between charts → use `report` with embedded charts. Dashboard is for cases where charts are the argument and prose only labels them.

## Skeleton

```
<header>      title + 1-line context + last-updated
<div kpi-row> 4-6 tiles with deltas
<section> primary chart, full width
<div chart-grid> secondary charts in 2 columns
<details> drill-down data table, collapsed
<footer>  source, refresh cadence
```

## Charts: SVG inline first

For bars, lines, scatter, and most distributions, hand-rolled SVG is smaller, instant-loading, dependency-free, and styled by the page's tokens (`var(--accent)` for bars, `var(--border)` for gridlines, `var(--text-muted)` for labels).

Set `viewBox`, let CSS size to `width: 100%; height: auto; max-height: 320px`. Include `role="img"` and `aria-label`.

Layout the secondary charts in a 2-column responsive grid that collapses to 1 column below 720px. The primary chart spans both columns.

## Use a library only when

- Hover tooltips with detail breakdowns are required
- Chart type is genuinely complex (heatmap, treemap, sankey, force graph)
- User already uses a specific library in their pipeline — match it

CDN imports:
- Chart.js: `https://cdn.jsdelivr.net/npm/chart.js@4`
- D3: `https://cdn.jsdelivr.net/npm/d3@7`
- Plotly: `https://cdn.plot.ly/plotly-2.35.0.min.js`

When using a library, inline a `<noscript>` paragraph stating the headline number so the doc isn't useless without JS.

## Drill-down table

Raw numbers behind every chart. Collapsed `<details>` by default.

## Color discipline

- One accent (`--accent`) for the primary series
- Neutrals for secondary
- Severity colors only for true pass/fail metrics — don't use red/green as ordinary series
- No rainbow palettes; if you need 5+ series, split into multiple charts

## Captions, not bodies

1-2 sentences per chart: the trend, the outlier, the comparison. Don't restate axis labels.

> Bad: "This chart shows PRs merged each day from Monday to Sunday."
> Good: "Thursday spike is the bulk-edit feature train (4 PRs landed together)."

## Acceptable deviations

- Date-range selector or series toggle if the user asks for exploration. Pure JS state, no backend.
- "Last updated" stamp with a faint pulse for live-status dashboards. No auto-refresh.
- For A vs B comparisons, share y-axis ranges explicitly — auto-scaled axes mislead.
