# Preset: explainer

"How X works", concept walkthroughs, onboarding docs, research summaries. The reader is new and chooses whether to invest each successive screen.

## Skeleton

```
<header>             title + 1-line "what you'll know after reading"
<aside class="tldr"> always present
<section> narrative section 1 (heading is a question)
<section> narrative section 2
... 3-6 sections
<dl class="glossary"> always present, even if short
<footer>
```

## TL;DR box

What it is, why it matters, the one gotcha — three bullets. Background tinted with `--accent-soft`, left border in `--accent`, uppercase "TL;DR" label.

## Questions as section headings

"How does the bucket refill?" beats "Bucket refill mechanics". Readers match their own question to the section.

## Collapsible deep-dives

Native `<details><summary>` for asides off the main path. Style the marker subtly so it doesn't shout.

## Inline SVG diagrams

For any process, lifecycle, or relationship — draw it. Use the page's color tokens so it feels part of the doc, not pasted in.

## Tabbed code samples

Multiple representations of the same idea (curl / Python / TS). Tab JS is in `references/snippets.md`. Underline the active tab using `--accent` as the bottom border.

## Glossary

4-6 terms minimum. Hover-link body terms to glossary entries via `<a href="#g-term">`. Layout as a two-column `<dl>` (term, definition) using grid.

## Comparison table

When teaching a choice ("X vs Y"), end with a "When to pick" row. That's the row readers actually came for.

## Acceptable deviations

- Small interactive diagram (animated token bucket) when the concept is dynamic and a frozen frame doesn't carry it. Under ~30 lines of JS — bigger is an `editor`.
- Drop the glossary for known-audience docs (ask first).
- Floating mini-TOC at wide viewports for explainers above ~5000 words.
