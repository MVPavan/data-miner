# Preset: editor

Interactive throwaway editors: prompt tuners, config editors, triage boards, calibration tools, annotation interfaces. The reader's job is to do something and export the result.

## Hard rule

Every editor ends with at least one export button. Output is paste-ready: JSON, markdown, prompt, YAML — whatever the user feeds back to the agent or commits. Without export, the work disappears.

## When editor vs other presets

Signal phrases: "tune", "tweak", "reorder", "tag", "approve/reject", "calibrate", "drag", "pick a value for". If the user just wants to read, use `report` or `explainer`.

## Skeleton

```
<header>                title + 1-line "what this lets you do"
<aside instructions>    2-3 line how-to, optional
<main editor-shell>
  <section controls>    inputs, knobs, drag targets
  <section preview>     live result
</main>
<div export-bar>        Copy as X · Reset
```

Two columns above 720px, stacked below. Use a grid.

## State, render, export

State pattern, copy-as-X JS, and drag-drop JS are all in `references/snippets.md`. Use them.

## Export bar

Sticky to the bottom of the viewport (`position: sticky; bottom: 0`) so the button never scrolls out of reach. Background `--surface`, border-top `--border`, buttons right-aligned. Include an empty `<span id="flash">` for confirmation text.

## Common patterns

**Live template preview** — editable textarea left, rendered output for several sample inputs right. Highlight variable slots. Pre-fill with a sensible default; never start empty.

**Drag-to-reorder buckets** — columns + draggable cards. Export emits final ordering grouped by bucket.

**Config editor with validation** — fields grouped by area, inline warnings on broken constraints (e.g. flag with prerequisite off). Export a *diff* of changed keys, not full config.

**Calibration / picker** — for values painful to express in text (color, easing curve, cron schedule, threshold values). Sliders + numeric display + live preview. SigLIP2 threshold tuning and hard-negative margin conditions fit here: sliders left, live detection preview right, copy thresholds as YAML at bottom.

## Don'ts

- No "save" button — there's no backend; "save" with no destination is a lie. Use "copy" or "download".
- No localStorage — artifacts are throwaway, persistence confuses.
- No login screen, ever.
- No fetches to external APIs unless explicitly requested.
- No 200KB script for a 10-card triage board.

## Acceptable deviations

- Alpine.js or Vue via CDN for complex editors (mention the cost in the response).
- Keyboard shortcuts in addition to visible buttons. Never keyboard-only.
- "Last export" `<details>` block so the user can review what they copied without re-clicking.
