# Preset: report

For plans, status updates, post-mortems, architecture docs, design specs, retrospectives — anywhere a reader expects to skim by section.

## Skeleton

```
<header>      title + 1-line subtitle
<div kpi-row> 3-5 KPI tiles
<section data-num="01"> ... </section>
<section data-num="02"> ... </section>
... 4-7 sections total
<footer>      sources, generated stamp
```

Reader path: KPIs orient, numbered sections enable jumping, footer establishes currency. The reader should answer "what is this and is it current?" in five seconds.

## Section order by report type

- **Implementation plan**: Milestones · Data flow · Mockups · Key code · Risks · Open questions
- **Status report**: KPIs · Highlights · Shipped · In flight · Blocked/slipped · Sources
- **Post-mortem**: Summary · Timeline · Root cause · Customer impact · Follow-ups · Sources
- **Architecture doc**: Context · System diagram · Components · Data flow · Failure modes · Capacity
- **Design spec**: Problem · Constraints · Proposal · Alternatives · Open questions

## Patterns

Derive layout fresh from tokens. For the severity tag color technique and copy-button JS, see `references/snippets.md`.

### KPI tile

Big number using `--fs-6`, label below using `--fs-2` muted, optional delta in `--fs-1` accent. Card has a border, modest padding, sits in a responsive grid (`auto-fit, minmax(180px, 1fr)`).

### Numbered section header

Large grey number (`--fs-5`, `--text-muted`, light font-weight) aligned with the section title on a shared baseline. Border-bottom below the header separates it from content.

### Risk / open-question table

Three columns: thing, severity, mitigation. Severity column uses the severity tag pill (color technique in `snippets.md`).

### Inline mockup

Sketch the UI using the page's tokens — `--surface` background, `--border` outline, `--text-muted` for placeholder text. Don't use screenshots. The mockup should feel like part of the doc, not a Figma export.

## Acceptable deviations

- Drop the KPI row if there are genuinely no numeric facts (rare — even "last updated" works).
- Sticky TOC sidebar on viewports >1080px when the doc has 8+ sections.
- Two-column layout for sections where a diagram pairs with its caption.
